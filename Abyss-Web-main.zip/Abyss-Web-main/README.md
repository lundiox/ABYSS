# Abyss Web

## Abyss is the best and most modern proxy to avoid modern censorship.
### discord.gg/goabyss

## Setup
```
git clone https://github.com/Abyss-Services/Abyss-Web
cd Abyss-Web
npm install
npm start
```

## Enviroment
Edit .env to change the port. The default port is 8080.

## License
Abyss uses GPL-3.0. Read it before you use Abyss and manipulate it's code.
