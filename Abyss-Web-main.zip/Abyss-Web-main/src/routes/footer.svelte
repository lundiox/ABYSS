<footer>
	<a href="https://discord.gg/goabyss" target="_blank">Discord</a>
	<a href="https://github.com/Abyss-Services" target="_blank">GitHub</a>
	<a href="https://intoabyss.org/apply" target="_blank">Apply for Staff</a>
	<p>Copyright Abyss Services 2023</p>
</footer>
